package com.DAD.SmartGym;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartGymApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartGymApplication.class, args);
	}

}

